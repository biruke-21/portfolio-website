document.addEventListener('DOMContentLoaded', function() {
            
    // 1. Initialize AOS
    AOS.init({
        duration: 1000,
        once: true // Animations only happen once
    });

    // 2. Typed.js Initialization
    if (document.querySelector('.typed-text')) {
        new Typed('.typed-text', {
            strings: [
                "Frontend Developer", 
                "Creative Designer",
                "UX/UI Expert"
            ],
            typeSpeed: 50,
            backSpeed: 50,
            loop: true
        });
    }
window.meassge =function(){
    alert("Thanks you for your invitation")
}
window.meassges =function(){
    alert("hello teacher it is the on going project please wait")
}
let le=document.getElementsByClassName('portfolio-link');
window.portfoliLlink=function(){
    alert("hello teacher this is on going project");
}
    // 3. Navbar Shrink & Scroll to Top Button Visibility
    const navbar = document.querySelector('.navbar');
    const scrollTopBtn = document.querySelector('.scroll-top');
    
    const checkScroll = () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
            scrollTopBtn.classList.add('active');
        } else {
            navbar.classList.remove('scrolled');
            scrollTopBtn.classList.remove('active');
        }
    };
    
    window.addEventListener('scroll', checkScroll);
    checkScroll(); // Run once on load

    // 4. Active Navbar Link on Scroll
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            // Buffer offset for better section activation
            if (window.scrollY >= sectionTop - 100) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === current) {
                link.classList.add('active');
            }
        });
    });

    // 5. Radial Progress Bar Animation
    // This is managed by Intersection Observer for performance
    const radialBars = document.querySelectorAll('.radial-bar');
    const circumference = 2 * Math.PI * 80; // 2 * PI * r (80)

    radialBars.forEach(bar => {
        const path = bar.querySelector('.path');
        const percentage = parseInt(path.dataset.percentage);
        
        // Calculate offset (how much of the circle is NOT filled)
        const offset = circumference - (percentage / 100) * circumference;
        
        // Initial setup
        path.style.strokeDasharray = circumference;
        path.style.strokeDashoffset = circumference; 

        // Store the final offset and set transition for animation
        bar.dataset.offset = offset;
        path.style.transition = 'stroke-dashoffset 2s ease-out';
    });
    
    // Intersection Observer to trigger the radial skill animations
    const skillsObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                radialBars.forEach(bar => {
                    const path = bar.querySelector('.path');
                    // Set the calculated offset to start the animation
                    path.style.strokeDashoffset = bar.dataset.offset;
                });
                // Unobserve so the animation only runs once
                observer.unobserve(entry.target); 
            }
        });
    }, { threshold: 0.2 }); // Trigger when 20% of the section is visible

    const skillsSection = document.getElementById('skills');
    if (skillsSection) {
        skillsObserver.observe(skillsSection);
    }
});
// Place this script just before the closing </body> tag or in a separate file
document.querySelector('form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent page refresh
  // Collect field values if needed
  alert('Your message has been sent (demo only).');
  // Optionally, clear the form
  event.target.reset();
});
